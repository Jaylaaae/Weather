package com.example.myapplication21

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var cityInput: EditText
    private lateinit var getWeatherButton: Button
    private lateinit var weatherResult: TextView
    private lateinit var weatherIcon: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        cityInput = findViewById(R.id.cityInput)
        getWeatherButton = findViewById(R.id.getWeatherButton)
        weatherResult = findViewById(R.id.weatherResult)
        weatherIcon = findViewById(R.id.weatherIcon)

        // Set click listener for the button
        getWeatherButton.setOnClickListener {
            val city = cityInput.text.toString()
            if (city.isNotEmpty()) {
                fetchWeatherData(city)
            }
        }
    }

    private fun fetchWeatherData(city: String) {
        RetrofitClient.instance.getWeather(city).enqueue(object : Callback<WeatherResponse> {
            override fun onResponse(call: Call<WeatherResponse>, response: Response<WeatherResponse>) {
                if (response.isSuccessful) {
                    val weather = response.body()
                    weather?.let {
                        val resultText = """
                            City: ${it.name}
                            Temperature: ${it.main.temp}°C
                            Humidity: ${it.main.humidity}%
                            Description: ${it.weather[0].description}
                        """.trimIndent()
                        weatherResult.text = resultText


                        when (it.weather[0].description.toLowerCase()) {
                            "clear sky" -> weatherIcon.setImageResource(R.drawable.sunny)
                            "few clouds" -> weatherIcon.setImageResource(R.drawable.cloudy)
                            "scattered clouds" -> weatherIcon.setImageResource(R.drawable.cloudy)
                            "overcast clouds" -> weatherIcon.setImageResource(R.drawable.cloudy)
                            "broken clouds" -> weatherIcon.setImageResource(R.drawable.cloudy)
                            "shower rain" -> weatherIcon.setImageResource(R.drawable.rainy)
                            "rain" -> weatherIcon.setImageResource(R.drawable.rainy)
                            "thunderstorm" -> weatherIcon.setImageResource(R.drawable.thunderstorm)
                            "snow" -> weatherIcon.setImageResource(R.drawable.snowy)
                            "mist" -> weatherIcon.setImageResource(R.drawable.misty)
                            else -> weatherIcon.setImageResource(R.drawable.sunny)
                        }
                    }
                } else {
                    weatherResult.text = "Error: ${response.message()}"
                }
            }

            override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                weatherResult.text = "Failure: ${t.message}"
            }
        })
    }
}