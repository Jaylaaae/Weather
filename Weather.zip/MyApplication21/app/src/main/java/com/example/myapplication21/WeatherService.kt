package com.example.myapplication21

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherService {
    @GET("data/2.5/weather")
    fun getWeather(
        @Query("q") city: String, // City name
        @Query("units") units: String = "metric", // Units (metric for Celsius)
        @Query("appid") apiKey: String = "bd5e378503939ddaee76f12ad7a97608" // Replace with your API key
    ): Call<WeatherResponse>
}